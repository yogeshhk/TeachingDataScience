# Projects

In addition to weekly assignments, there are two projects to complete for the semester.

1. [Simulation Project](simulation) - a 2 week coding exercising synthesizing concepts from first half of semester and/or expanding on an earlier assignment.
2. [Final Project](final) - a 3 week creative project that builds off or is inspired by the concepts we've covered this semester. 
