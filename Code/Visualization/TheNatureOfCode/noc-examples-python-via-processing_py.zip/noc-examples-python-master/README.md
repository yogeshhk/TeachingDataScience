# The-Nature-of-Code-Examples Python

This is the repository for a Python port of [The Nature of Code book](http://natureofcode.com/).  If you are looking for the book's raw content (text, illustrations, images, CSS, etc.), have a look at [The Nature of Code repo](https://github.com/shiffman/The-Nature-of-Code).

The original [Processing](http://processing.org) examples [can be found here](https://github.com/shiffman/The-Nature-of-Code-Examples), along with a [list of other ports](https://github.com/shiffman/The-Nature-of-Code-Examples/blob/master/README.md).

This port is made possible by [processing.py](https://github.com/jdf/processing.py).


