# nlp_tourism
Named entity relevant project
data set link

https://drive.google.com/drive/folders/1QMxZaAMIDFBGCJaWc-453z4NLUDQHE9X?usp=sharing
