# Zerodha Live Automate Trading using AI ML on Indian stock market #

#  Disclaimer #
These all code are for information, knowledge and presentation purpose only, developed by ashish kumar-software developer while working on project zerodha in "Angel virtual world pvt ltd" (2018-2019) , and are the asset of "Angel virtual world pvt ltd. B-93, Unity Tower, 3rd Floor Mayapuri Industrial Area Phase I, New Delhi, Delhi 110064 ". 


# About the project # 
* This project is based on Online trading using Artificial Intelligence Machine leaning with python on Indian Stock Market, trading using live bots indicators screener and backtesters using rest api and websocket on zerodha kite.

* Zerodha    - online broker for Automated Python program for trading in Indian stock market.  

  1. Getting Started with Zerodha ,Starting new project with zerodha .
  2. BACKTESTIG_PROGRAM == What is Backtesting?
  3. Historical Data Download Code for any stock of Stock Market.
  4. Stock_Screener (GUPPY)== What is Stock_Screener?
  5. INDICATORS (ATR,RSI,SMA,EMA,Bollinger band ) on Historical_data 'SBI'.
  6. Live_Trading_BOTS == What is a Trading BOT ?
  7. Trading Live BOT  (1) == BUY-SELL BOT on RSI strategy
  8. Trading Live BOT  (2) == GUPPY strategy bot
  9. Trading Live BOT  (3) == Automated bot of BUY-SELL bot on Guppy indicator 4 colours
  10. Trading Live BOT (4) == Advance Multiple bot of buy/sell in one BOT with screener, backtestig
