<!--- Make sure to update this training data file with more training examples from https://forum.rasa.com/t/rasa-starter-pack/704 --> 

## intent:goodbye  
- Bye 			
- Goodbye
- See you later
- Bye bot
- Goodbye friend
- bye
- bye for now
- catch you later

## intent:greet
- Hi
- Hey
- Hi bot
- Hey bot
- Hello
- Good morning
- hi again

## intent:thanks
- Thanks
- Thank you
- Thank you so much
- Thanks bot
- Thanks for that

## intent:affirm
- y
- Y
- yes
- yes sure
- absolutely

## intent:deny
- no
- never
- I don't think so
